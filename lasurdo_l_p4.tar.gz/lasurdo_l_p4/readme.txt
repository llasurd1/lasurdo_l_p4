C++
make
 “I have done this assignment completely on my own. I have not
copied it, nor have I given my solution to anyone else. I understand that if I am involved in plagiarism or cheating I will have to sign
an official form that I have cheated and that this form will be stored in my official university record. I also understand that I will
receive a grade of 0 for the involved assignment for my first offense and that I will receive a grade of “F” for the course for any
additional offense.”
Liam Lasurdo
My programs logic seems to be working but there are several issues with some of the files, I assume due to some kind of memory issue related to the size of the array generated for
the dynamic programming solution. mediumInput works perfectly. smallInput works most of the time, but will occasionally give an extrememly large answer for the max Profit,
running it again/a few more times should fix this. input.txt works for the first problem but not the second for some reason. badGreedyInput segfaults, I assume due to the amount of 
memory needed to have an array of that size. And badImprovedGreedyInput.txt, the first problem does not work but the second one does. I am unsure as to why some of them have issues 
but I have exhaused myyself testing and trying to figure it out.
